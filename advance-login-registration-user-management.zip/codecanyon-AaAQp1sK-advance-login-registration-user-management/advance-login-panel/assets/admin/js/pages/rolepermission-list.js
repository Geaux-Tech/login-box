

$(document).ready(function(){
	"use strict";
		$('#datatable').DataTable({
			columnDefs: [
			   { orderable: false, targets: -1 }
			]
		});
	});