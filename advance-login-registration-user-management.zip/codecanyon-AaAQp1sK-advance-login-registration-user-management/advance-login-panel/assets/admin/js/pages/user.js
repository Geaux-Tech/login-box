"use strict";
$(document).ready(function(){
		$('#datatable').DataTable({
		});
	});