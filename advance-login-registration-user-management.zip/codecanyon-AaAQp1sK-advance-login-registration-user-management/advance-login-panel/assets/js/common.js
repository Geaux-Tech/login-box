
$(document).ready(function(){
	$('.datepicker').datetimepicker({
		format: 'Y-m-d',
		timepicker: false,
		closeOnDateSelect: true,
		scrollInput: false,
		maxDate: 'now()',
	});

	$('.summernote').summernote({
	        height: 180,
	        tabsize: 2
	      });


	$(this).closest('tr').find('.chkcol:checked');
		$(this).find('.view').each(function () {
           if (this.checked) {
               $(this).closest('tr').find('.chkcol').removeAttr("disabled");
           }else{
           	$(this).closest('tr').find('.chkcol').attr("disabled", true).attr("checked", false);
           	$(this).removeAttr("disabled");
           }
		});

		$('.view').click(function(){
			if (this.checked) {
			 $(this).closest('tr').find('.chkcol').removeAttr("disabled");

			}else{
			 $(this).closest('tr').find('.chkcol').attr("disabled", true).attr("checked", false);
			 $(this).closest('tr').find('.chkcol').prop("checked", false);
			 $(".view").removeAttr("disabled");
			}
		});

		$('.chkrow').click(function(){
			$(this).closest('tr').find('input:checkbox').not(this).prop('checked', this.checked);
			if(this.checked){
			$(this).closest('tr').find('.chkcol').removeAttr("disabled");
			}else{
				$(this).closest('tr').find('.chkcol').attr("disabled", true).attr("checked", false);
				$(".view").removeAttr("disabled");
			}

		});
		$('.chkcol').click(function(){
			if ($(this).closest('tr').find('.chkcol:checked').length == $(this).closest('tr').find('.chkcol').length) {
					$(this).closest('tr').find('.chkrow').prop('checked', true);
					$(this).closest('tr').find('.chkcol').removeAttr("disabled");
			}
			else{
			}
		})
	
});