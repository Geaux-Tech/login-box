<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
    private $data;
    /**
    @param void
    @return void
    */
    function __construct(){
        parent::__construct();
        if(!$this->session->userdata('admin_id')){
            redirect(base_url('admin/signin'));
        }
        $this->load->library('csvimport');
        $this->load->model('admin/Admin_Model','admin');
        $response = $this->admin->edit($this->session->userdata('admin_id'));
        $settings = $this->load->model('admin/Settings_Model','settings');
        $module_setting = $this->load->model('admin/ModuleSetting_Model','module_setting');
	    $role = $this->load->model('admin/RolePermission_Model','role');
	    $this->data['settings'] = $this->settings->get();
        if($response['status']===true){
            $users = $this->load->model('admin/User_Model','user');
            $this->data['admin'] = $response['record'];
            $role = $this->load->model('admin/RolePermission_Model','role');
            $this->data['userrole']= $this->role->edit($this->data['admin']['role']);
            $this->page = 'users';
            chkaccess($this->data,$this->page,'view');
        }
        else{
            redirect(base_url('admin/signin'));
        }
    }

    /**
    @param void
    @return void
    */
    public function index(){
        chkaccess($this->data,$this->page,'view');
        $this->data['users'] = $this->user->get();
        $this->load->view('admin/users/list',$this->data);
    }

    public function create(){
        chkaccess($this->data,$this->page,'create');
         $this->data['module'] = $this->module_setting->get();
        $this->data['role'] = $this->role->get();
        $this->load->view('admin/users/userform',$this->data);
    }


   
    /**
    @param void
    @return void
    */
    public function store(){
        chkaccess($this->data,$this->page,'create');
        $this->data['role'] = $this->role->get();
        $user ='user';
        $module=$this->module_setting->getattribute($user);
        $validation = [
                ['field' => 'firstname','label' => 'First Name','rules' => 'trim|required|xss_clean'],
                ['field' => 'lastname','label' => 'Last Name','rules' => 'trim|required|xss_clean'],
                ['field' => 'username','label' => 'Username','rules' => 'trim|required|xss_clean|is_unique[admins.username]','errors'=>['is_unique'=>'The %s is already taken']],
                ['field' => 'email','label' => 'Email','rules' => 'trim|required|xss_clean|valid_email|is_unique[admins.email]','errors'=>['is_unique'=>'The %s is already taken']],
                ['field' => 'password','label' => 'Password','rules' => 'required|min_length[4]|xss_clean'],
                ['field' => 'confirm_password','label' => 'Confirm Password','rules' => 'required|matches[password]'],
                ['field' => 'role','label' => 'role','rules' => 'required'],
            ];
            if(!empty($module['record'])){
                foreach ($module['record'] as $key => $value) {
                    # code...
                    $validate_value = json_decode($value['validate_attr'],true);
                    $r = $validate_value['rules'];
                    $value['validate_attr'] = implode("|",(array) $r);
                    if($value['type'] == "checkbox(multiple select)"){
                        $validation[] =  ['field' => $value['slug'].'[]','label' =>ucfirst($value['name']),'rules' => $value['validate_attr']];
                    }else{
                    $validation[] = 
                        ['field' => $value['slug'],'label' =>ucfirst($value['name']),'rules' => $value['validate_attr']];
                    }

                }
            }
        $this->form_validation->set_rules($validation);
        if($this->form_validation->run() == false){
            $response['status'] = false;
            $response['validation']= validation_errors();
            echo json_encode($response);
        }
        else{
            unset($_POST['confirm_password']);
            $_POST['password'] = md5($_POST['password']);
            $_POST['created_at'] = date('Y-m-d H:i:s');
            if(!empty($module['record'])){
            foreach ($module['record'] as $key => $value) {
                $d[$value['slug']] = $_POST[$value['slug']];
                unset($_POST[$value['slug']]);
             }
            $_POST['module'] = json_encode($d);
            }
            $response = $this->user->store($_POST);
            if($response['status']===true){
                $this->session->set_flashdata('success', $response['message']);
                $response['status'] = true;
                echo json_encode($response);
            }
            else{
                $this->session->set_flashdata('error', $response['message']);
                $response['status'] = false;
                 echo json_encode($response);
            }
        }
    }

    

    public function edit($id){
        chkaccess($this->data,$this->page,'edit');
        $this->data['id'] = $id;
        $this->data['user'] = $this->user->edit($id);
        $this->data['role'] = $this->role->get();
        if($this->data['user']['status']===false){
            redirect(base_url('admin/user'));
        }
        if(!empty($this->data['user'])){
            $this->data['user']['record']['module'] = json_decode($this->data['user']['record']['module'],true);
        }
        $this->load->view('admin/users/userform',$this->data);
    }

   

    public function update($id){
        $this->data['id'] = $id;
        $this->data['role'] = $this->role->get();
        $user ='user';
        $module=$this->module_setting->getattribute($user);
        $validation = [
                ['field' => 'firstname','label' => 'First Name','rules' => 'trim|required|xss_clean'],
                ['field' => 'lastname','label' => 'Last Name','rules' => 'trim|required|xss_clean'],
                ['field' => 'username','label' => 'Username','rules' => 'trim|required|xss_clean','errors'=>['is_unique'=>'The %s is already taken']],
                ['field' => 'email','label' => 'Email','rules' => 'trim|required|xss_clean|valid_email','errors'=>['is_unique'=>'The %s is already taken']],
                ['field' => 'password','label' => 'Password','rules' => 'min_length[4]|xss_clean'],
                ['field' => 'confirm_password','label' => 'Confirm Password','rules' => 'matches[password]'],
                ['field' => 'role','label' => 'role','rules' => 'required'],
            ];
            if(!empty($module['record'])){
        foreach ($module['record'] as $key => $value) {
            # code...
            $validate_value = json_decode($value['validate_attr'],true);
            $r = $validate_value['rules'];
            $value['validate_attr'] = implode("|",(array) $r);
            if($value['type'] == "checkbox(multiple select)"){
                $validation[] =  ['field' => $value['slug'].'[]','label' =>ucfirst($value['name']),'rules' => $value['validate_attr']];
            }else{
            $validation[] = 
                ['field' => $value['slug'],'label' =>ucfirst($value['name']),'rules' => $value['validate_attr']];
            }

        }
    }
        $this->form_validation->set_rules($validation);
        if($this->form_validation->run() == false){
            $response['status'] = false;
            $response['validation']= validation_errors();
            echo json_encode($response);
        }
        else{
            unset($_POST['confirm_password']);
            if($_POST['password']!=''){
                $_POST['password'] = md5($_POST['password']);
            }
            else{
                unset($_POST['password']);
            }
             if(!empty($module['record'])){
            foreach ($module['record'] as $key => $value) {
                $d[$value['slug']] = $_POST[$value['slug']];
                unset($_POST[$value['slug']]);
             }
            $_POST['module'] = json_encode($d);
         }
            if($id==$this->session->userdata('admin_id')){
                unset($_POST['role']);
            }

            $response = $this->user->update($id,$_POST);
            if($response['status']===true){
                $this->session->set_flashdata('success', $response['message']);
                $response['status'] = true;
                echo json_encode($response);
            }
            else{
                $this->session->set_flashdata('error', $response['message']);
                $response['status'] = false;
                 echo json_encode($response);
            }
        }
    }

    public function destroy(){
        chkaccess($this->data,$this->page,'delete');
        
        $data = $this->input->post('data');
        foreach ($data as $key => $value) {
            $response = $this->user->destroy($value);
        }
        $message = $this->session->set_flashdata('success', $response['message']);
        echo $response;
    }

    public function status($id,$status){
        $response = $this->user->status($id,$status);
        $this->session->set_flashdata('success', $response['message']);
        redirect(base_url('admin/user'));
    }

    public function exportCSV(){ 
           // file name 
           $filename = 'users_'.date('Ymd').'.csv'; 
           header("Content-Description: File Transfer"); 
           header("Content-Disposition: attachment; filename=$filename"); 
           header("Content-Type: application/csv; ");
           
           // get data 

            $usersData = $this->user->getheaders();
            $fieldlist = $this->user->getfieldlist();
            foreach($usersData as $k=>$v){
                $m = json_decode($v['module'],true);
                if(is_array($m)){
                foreach($m as $k1=>$v1){
                    $usersData[$k][$k1] = $v1; 
                }
            }
                if(isset($fieldlist)){
                    foreach ($fieldlist as $key1 => $value1) {
                       if(!isset($usersData[$k][$value1['name']])){
                        $usersData[$k][$value1['name']] = '';
                       }
                    }
                }
                unset($usersData[$k]['module']);
            }
      
           // file creation 
           $file = fopen('php://output', 'w');
         
           $header = array("Firstname","Lastname","Username","Email","Date of Birth(Y-mm-dd)"); 
            if(isset($fieldlist)){
                foreach ($fieldlist as $key => $value) {
                    $header[] = ucfirst($value['name']);
                }
            }
           fputcsv($file, $header);
           foreach ($usersData as $key=>$line){ 
             fputcsv($file,$line); 
           }
           fclose($file); 
            exit;
           
    }

    public function ShowimportCsv(){
         $this->load->view('admin/users/importfile',$this->data);
    }

    public function importCSV(){
          $file_data = $this->csvimport->get_array($_FILES["csv_file"]["tmp_name"]);
          if($_FILES["csv_file"]['tmp_name'] == null){
            $this->session->set_flashdata('error', 'Please Enter File.');

            redirect(base_url('admin/user/ShowimportCsv'));
          }
          foreach($file_data as $k=>$row)
          {

            if(!isset($row["Firstname"]) || !isset($row["Lastname"]) || !isset($row["Username"]) || !isset($row["Email"]) || !isset($row["Date of Birth(Y-mm-dd)"])  || !isset($row["Password"])){  
              
                 $this->session->set_flashdata('error', 'Invalid Format.');

                redirect(base_url('admin/user/ShowimportCsv'));
            }
            $password = md5($row["Password"]);
            
            $usersData = $this->user->getfieldlist();
            foreach ($usersData as $key => $value) {
                if(isset($row[ucfirst($value['name'])])){
                    $a[str_replace(' ', '_', strtolower($value['name']))] = $row[ucfirst($value['name'])];
                }else{
                    $a[str_replace(' ', '_', strtolower($value['name']))] = '';
                }
            }
            $data = array(
                'firstname' => $row["Firstname"],
                'lastname'  => $row["Lastname"],
                'username'  => $row["Username"],
                'email'   => $row["Email"],
                'birthdate'   => $row["Date of Birth(Y-mm-dd)"],
                'password'   =>  $password,
                'role'   =>  '3',
                'module' => json_encode($a),
            );
     
           $response = $this->user->checkduplicate($data);
            if($response['status']===true){
                $this->user->update($response['records']['id'],$data);
            }else{

             $this->user->store($data);
            }    
          }
           
          $this->session->set_flashdata('success', 'Your file is successfully imported.');
         redirect(base_url('admin/user'));
     
    }

    public function exportCSVformat(){
          $filename = 'csv_formate_'.date('Ymd').'.csv'; 
           header("Content-Description: File Transfer"); 
           header("Content-Disposition: attachment; filename=$filename"); 
           header("Content-Type: application/csv; ");
               
           // file creation 
           $file = fopen('php://output', 'w');
        
           $header = array("Firstname","Lastname","Username","Password","Email","Date of Birth(Y-mm-dd)"); 
            $usersData = $this->user->getfieldlist();
            foreach ($usersData as $key => $value) {
                $header[] = ucfirst($value['name']);
            }
           fputcsv($file, $header);
          
           fclose($file); 
           exit; 
    }

    
}
