<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	private $data;
	/**
    @param void
    @return void
    */
	function __construct(){
        parent::__construct();
        if(!$this->session->userdata('admin_id')){
        	redirect(base_url('admin/signin'));
        }
        $this->load->model('admin/Admin_Model','admin');
        $response = $this->admin->edit($this->session->userdata('admin_id'));
	    $settings = $this->load->model('admin/Settings_Model','settings');
	    $this->data['settings'] = $this->settings->get();
    	if($response['status']===true){
			$this->data['admin'] = $response['record'];
            $role = $this->load->model('admin/RolePermission_Model','role');
            $this->data['userrole']= $this->role->edit($this->data['admin']['role']);
        
        }
		else{
			redirect(base_url('admin/signin'));
		}
    }

    /**
    @param void
    @return void
    */
	public function index(){
        $this->load->model('admin/User_Model','user');
        $this->load->model('admin/Cms_Model','cms');

        $day = date('w'); 
        $week_start = date('Y-m-d', strtotime('-'.$day.' days'));
        $week_end = date('Y-m-d', strtotime('+'.(6-$day).' days'));
 
   
        $this->data['users'] = $this->user->count();
        $this->data['last_login'] = $this->user->lastlogin();
        $this->data['last_register'] = $this->user->lastregister();
        $this->data['registered'] = $this->user->weeklyregistered($week_start,$week_end);
        $this->data['cms'] = $this->cms->count();
        $this->data['registered'] =  implode(",",$this->data['registered']);
       
		$this->load->view('admin/dashboard',$this->data);
	}
}
