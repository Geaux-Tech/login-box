<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

	if(!function_exists('asset_url()')){
		function asset_url(){
			return base_url().'assets/';
		}
	}
	
	function email_config(){
		$config = array(
				'protocol' => SMTP_PROTOCOL,
				'smtp_host' => SMTP_HOST,
				'smtp_port' => SMTP_PORT,
				'smtp_user' => SMTP_USER,
				'smtp_pass' => SMTP_PASSWORD,
				'mailtype' => SMTP_MAILTYPE,
				'charset' => SMTP_CHARSET,
				'wordwrap' => SMTP_WORDWRAP
			);
		return $config;
	}

	if(!function_exists('j')){
		function j($data){
			echo "<pre>";print_r($data);exit;
		}
	}

	function chkaccess($data,$page,$action){		
		// echo $action;exit;
		if(!isset($data['userrole']['record']['permissions'][$page][$action]) || $data['userrole']['record']['permissions'][$page][$action] !== true){  
            
                redirect(base_url('admin/dashboard'));
            }
	}

	function tracking(){
		$CI =& get_instance();
		$CI->load->library('session');
		if($CI->session->userdata('tracked')){
		}
		else{
			$CI->session->set_userdata('tracked',true);
			$CI->load->library('user_agent');
			$CI->load->database();
			$data = array();
			$data['ip'] = $CI->input->ip_address();
			$data['agent'] = $CI->agent->agent;

			$d = file_get_contents('http://www.geoplugin.net/xml.gp?ip='.$CI->input->ip_address());
			$xml = simplexml_load_string($d, 'SimpleXMLElement', LIBXML_NOCDATA);
			$location_details = json_encode($xml);
			$location = json_decode($location_details);
			@ $info = $location->geoplugin_city.','.$location->geoplugin_countryName;
			//city,country
			$data['info'] = $info;
			$data['created_at'] = date('Y-m-d H:i:s');
			$CI->db->insert('tracking',$data);
		}
	}
	tracking();